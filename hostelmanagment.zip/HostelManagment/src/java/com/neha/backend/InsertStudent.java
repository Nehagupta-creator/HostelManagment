/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class InsertStudent extends HttpServlet  {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }
    

    
    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out=resp.getWriter();
        HttpSession session=req.getSession();
        String sname=req. getParameter("name1");
        String semail=req. getParameter("email1");
        String sphone=req. getParameter("phone1");
        String sprofession=req. getParameter("profession1");
        String saddress=req. getParameter("address1");
        
        Connection con=null;
        try
        {
         con=DbConnection.getConnect();
         con.setAutoCommit(false);
         PreparedStatement ps=con.prepareStatement("insert into student(name, email,phoneno,profession,address) values(?,?,?,?,?)");
         ps.setString(1,sname);
         ps.setString(2,semail);
         ps.setString(3,sphone);
         ps.setString(4,sprofession);
         ps.setString(5,saddress);
         int i= ps.executeUpdate();
        
         
         PreparedStatement ps1=con.prepareStatement("insert into picture(name, email,path) values(?,?,?)");
         
         ps1.setString(1,sname);
         
         ps1.setString(2,semail);
        
        ps1.setString(3,"sample image1.jpg");
         
          int i1= ps1.executeUpdate();
          
         
           
           
           
         if (i>0 && i1>0) 
         {
             
             
             
             con.commit();
             
             
             session.setAttribute("session_sname", sname);
             session.setAttribute("session_semail", semail);
             session.setAttribute("session_sphoneno", sphone);
             session.setAttribute("session_sprofession", sprofession);
             session.setAttribute("session_saddress", saddress);
             session.setAttribute("session_picture", "sample image1.jpg");
             
             req.setAttribute("Success_msg", "Student Added Successfully");
             
             
             RequestDispatcher rs=req.getRequestDispatcher("success.jsp");
             rs.include(req, resp);
             RequestDispatcher rs1=req.getRequestDispatcher("viewstudent.jsp");
             rs1.include(req, resp);
             
             
             
         }
         else
         {
             
              out.println("11111111");
             con.rollback();
             
             
             req.setAttribute("error_msg", "Student Not  Added  Due to Error");
             
             RequestDispatcher rs=req.getRequestDispatcher("error2.jsp");
             rs.include(req, resp);
             RequestDispatcher rs1=req.getRequestDispatcher("insertstudent.jsp");
             rs1.include(req, resp);
           
           
         }
        
        
        }
        catch(Exception e)
        {
            
            try{
            
           
           con.rollback();
           
           
           req.setAttribute("error_msg", "Student Not  Added  Due to Error");
           RequestDispatcher rs=req.getRequestDispatcher("error2.jsp");
             rs.include(req, resp);
             RequestDispatcher rs1=req.getRequestDispatcher("insertstudent.jsp");
             rs1.include(req, resp);
           
            }
            catch(Exception ee)
            {
               out.println(ee);
            
            }
       out.println(e);
        
        }
        finally
        {
        
        try{ 
           con.close();
        }
        catch(Exception e)
        {
          e.printStackTrace();
        }
        
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
}
