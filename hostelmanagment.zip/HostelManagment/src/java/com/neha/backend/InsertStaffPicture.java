/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author ABC
 */
public class InsertStaffPicture  extends HttpServlet
{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        
        PrintWriter out=resp.getWriter();
       HttpSession session=req.getSession();
      // System.out.println("11111111");
       String email=req.getParameter("email");
       System.out.println(email);
       //System.out.println("22222222");
        Connection con=null;
         String file_name=null;
        
       try{
        DiskFileItemFactory factory=new DiskFileItemFactory();
        ServletFileUpload sfu=new ServletFileUpload(factory);
        List<FileItem> items=sfu.parseRequest(req);
         out.println(items);
        FileItem item=items.get(1);
        String file_path=item.getName();
       
        File file=new File(file_path);
         file_name=file.getName();
        
        File f1=new File(PathDetails.Profile_Path +file_name);
        item.write(f1);
        
        
          }
       catch(Exception e)
       {
        out.print(e);
       
       }
       
       try{
       con=DbConnection.getConnect();
       con.setAutoCommit(false);
       PreparedStatement ps=con.prepareStatement("update staffpicture set path=? where email=? ");
       ps.setString(1, file_name);
       ps.setString(2,email);
       int i=ps.executeUpdate();
       if(i>0)
       {
           session.setAttribute("session_staffpicture", file_name);
           con.commit();
           resp.sendRedirect("viewstaff.jsp");
       
       }
       else{
           
           con.rollback();
           resp.sendRedirect("editstaffpicture.jsp");
       
       }
       
       
       
       
       }
       catch(Exception ee)
       {
           try{
            con.rollback();
           }
           catch(Exception eee)
           {
               eee.printStackTrace();
           
           }
           ee.printStackTrace();
       }
       finally
       {
        try{
         con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        
        }
       
       }
     
    }
    
}
