/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ABC
 */
public class Contact extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        PrintWriter out= resp.getWriter();
        String name2=req.getParameter("name1");
        String email2=req.getParameter("email1");
        String no2=req.getParameter("no1");
        String message2=req.getParameter("message1");
        
        
        
        Connection con=null;
        try
        {
        con=DbConnection.getConnect();
        con.setAutoCommit(false);
        PreparedStatement ps=con.prepareStatement("insert into contact_us(name,email,contactno,message)values(?,?,?,?)  ");
        ps.setString(1, name2);
        ps.setString(2, email2);
        ps.setString(3, no2);
        ps.setString(4, message2);
        int i= ps.executeUpdate();
        if(i>0)
        {
            con.commit();
        req.setAttribute("Success_msg","Your Query has Been Submit Successfully Our Team Will Contact you As soon As Possible");
        
            RequestDispatcher rd=req.getRequestDispatcher("success.jsp");
            rd.include(req, resp);
             RequestDispatcher rd1=req.getRequestDispatcher("contact.jsp");
            rd1.include(req, resp);
            
        }
        else
        {
            con.rollback();
             req.setAttribute("error_msg","Your Query has not been Submit  there is an error occured!!");
            
             RequestDispatcher rd2=req.getRequestDispatcher("error2.jsp");
            rd2.include(req, resp);
             RequestDispatcher rd3=req.getRequestDispatcher("contact.jsp");
            rd3.include(req, resp);
            
        
        }
        
        
        
         }
        catch(Exception e)
        {
            try{
             con.rollback();
            }
            catch(Exception ee)
            {
            ee.printStackTrace();
            }
             req.setAttribute("error_msg","Your Query has not been Submit  there is an error occured!!");
            
             RequestDispatcher rd2=req.getRequestDispatcher("error.jsp");
            rd2.include(req, resp);
             RequestDispatcher rd3=req.getRequestDispatcher("contact.jsp");
            rd3.include(req, resp);
          e.printStackTrace();
        }
        finally
        {
        try
        {
            con.close();
        }
        catch(Exception e)
        {
          e.printStackTrace();
        
        }
       
        }
        
       
    }
    
    
}
