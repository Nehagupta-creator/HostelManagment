/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class AdminLogin extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        String email=req.getParameter("email1");
         String password=req.getParameter("pass1");
          
          
         
         Connection con=null;
         try{
         
         con=DbConnection.getConnect();
         PreparedStatement ps=con.prepareStatement("select * from register where email=? and password=?");
         ps.setString(1,email);
         ps.setString(2,password);
         ResultSet rs=ps.executeQuery();
          
         
          if(rs.next())
             
         {
            
              resp.sendRedirect("admin.jsp");
              HttpSession session=req.getSession();
              session.setAttribute("admin_email", email);
         }
         
           
         else
         {
             resp.sendRedirect("error.jsp");
         
         }
         
         }
         catch(Exception e)
         {
         e.printStackTrace();
         }
         finally
         {
          try{
              con.close();
          
          }
          catch(Exception ee)
          {
            ee.printStackTrace();
          }
         }
        
    }
    
            
    
}
 
    

