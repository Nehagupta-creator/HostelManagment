/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class Register extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
     
      String name2=req.getParameter("name1");
      String email2=req.getParameter("email1");
      String password2=req.getParameter("pass1");
      String address2=req.getParameter("address1");
      String gender2=req.getParameter("gender1");
      Connection con=null;
      try
      {
      con=DbConnection.getConnect();
      con.setAutoCommit(false);
      PreparedStatement ps= con.prepareStatement("insert into register(name,email,password,address,gender)values(?,?,?,?,?)");
      ps.setString(1, name2);
      ps.setString(2, email2);
      ps.setString(3,password2);
      ps.setString(4, address2);
      ps.setString(5, gender2);
      int i=ps.executeUpdate();
      if(i>0)
      {
          con.commit();
          HttpSession session=req.getSession();
          session.setAttribute("session_email", email2);
          session.setAttribute("session_password", password2);
           session.setAttribute("session_name", name2);
          resp.sendRedirect("welcome.jsp");
          
      
      }
      else
      {
        con.rollback();
        resp.sendRedirect("error.jsp");
      }
              
      }
      catch(Exception e)
      {
          try{
          con.rollback();
          }
          catch(Exception ee)
          {
              ee.printStackTrace();
          
          }
       e.printStackTrace();
      }
      finally
      {
       try
       {
           con.close();
       
       }
       catch(Exception e)
       {
        e.printStackTrace();
       }
      }
      
        
    }
    
    
}
